
import { FaHome } from "react-icons/fa";
function Home() {
    return (
        <>
            <div style={{ backgroundColor: "beige", height: "91vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <h1 style={{ fontSize: "70px", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <FaHome />OME
                </h1>
            </div>
        </>
    )
}

export default Home;

