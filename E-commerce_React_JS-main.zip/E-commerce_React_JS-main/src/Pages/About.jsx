function About() {
    return (
        <>
            <div style={{ backgroundColor: "#FFE6EE", height: "91vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <h1 style={{ fontSize: "70px", display: "flex", alignItems: "center", justifyContent: "center" }}>
                   ABOUT
                </h1>
            </div>
        </>
    )
}

export default About;